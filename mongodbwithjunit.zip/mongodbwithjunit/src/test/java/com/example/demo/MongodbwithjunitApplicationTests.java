package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.model.Student;
import com.example.demo.repository.StudentRepo;

@SpringBootTest
class MongodbwithjunitApplicationTests {

	@Autowired
	StudentRepo studentrepo;

	@Test
public void create() {
			Student pp=new Student();
			pp.setSid(5);
			pp.setSname("adithya");
			studentrepo.save(pp);
		}
	@Test
	public void read() {
		Iterable<Student> List=studentrepo.findAll();	
	}
	@Test
	public void delete() {
		studentrepo.deleteById(0);
	}
	@Test
	public void update() {
		Student pp=studentrepo.findById(2).get();
		pp.setSname("abhi");
		studentrepo.save(pp);
	}
}



package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mongoo1Application {

	public static void main(String[] args) {
		SpringApplication.run(Mongoo1Application.class, args);
	}

}

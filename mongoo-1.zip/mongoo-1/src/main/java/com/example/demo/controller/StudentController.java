package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.Student;
import com.example.demo.repository.StudentRepo;

@Controller
public class StudentController {
	@Autowired
	StudentRepo studentrepo;

	
	@RequestMapping("index")
	public String index(){
		return "index.jsp";
	}
	@RequestMapping("addStudent")
	public String addStudent(Student stu) {
		studentrepo.save(stu);
		return "index.jsp";

}
	@RequestMapping("getStudent")
	public ModelAndView studentsearch(@RequestParam int sid) {
		ModelAndView mv=new ModelAndView("display.jsp");
		Student student=studentrepo.findById(sid).orElse(new Student());
		mv.addObject(student);
		return mv;
		
	}
	@RequestMapping("deleteStudent")
	public ModelAndView deleteStudent(@RequestParam int sid) {
		ModelAndView mv=new ModelAndView("delete.jsp");
		Student student=studentrepo.findById(sid).orElse(new Student());
		studentrepo.deleteById(sid);
		mv.addObject(student);
		return mv;
	}
	@RequestMapping("updateStudent")
	public ModelAndView updateStudent(@RequestParam int sid) {
		ModelAndView mv=new ModelAndView("update.jsp");
		Student student=studentrepo.findById(sid).orElse(new Student());
		studentrepo.deleteById(sid);
		mv.addObject(student);
		return mv;
	
}
	
	}


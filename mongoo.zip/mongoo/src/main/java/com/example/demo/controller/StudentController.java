package com.example.demo.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Student;
import com.example.demo.repository.StudentRepo;



@RestController
public class StudentController {
	@Autowired
	StudentRepo studentrepo;
	
	@PostMapping("/addStudent")
	public String addStudent(@RequestBody Student stu) {
		studentrepo.save(stu);
		return "record inserted succesfully";
		
	}
	@GetMapping("/display/{sid}")
	public List<Student>display(@PathVariable int sid){
		return studentrepo.findAll();
	}
	@DeleteMapping("/sdelete/{sid}")
	public String sdelete(@PathVariable int sid) {
		studentrepo.deleteById(sid);
		return "Deleted sucessfully";
	}
	@PutMapping("/supdate")
	public String supdate(@RequestBody Student stu) {
		Student estu=studentrepo.findById(stu.getSid()).get();
		estu.setSname(stu.getSname());
		estu.setSaddress(stu.getSaddress());
	    studentrepo.save(estu);
	    
		return "Record updated sucessfully  at sid:"+ " " + stu.getSid();
	}
}